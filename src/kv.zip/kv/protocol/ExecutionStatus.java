package kv.protocol;

public enum ExecutionStatus {
	OK_SUCCESS,
	OK_ADDED,
	OK_UPDATED,
	OK_DELETED,
	ERR_NOT_FOUND,
	INVALID_COMMAND,
	ERR_TIMEOUT,
	ERR_STORAGE,
	NOT_READY
}
