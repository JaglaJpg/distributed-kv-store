package kv.cluster;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

public class ClusterReaderThread extends Thread{
	private PeerConnection peer;
	private Socket socket;
	private BufferedReader in;
	
	private ClusterManager clusterManager;

	public ClusterReaderThread(
	        Socket socket,
	        PeerConnection peer,
	        ClusterManager clusterManager) throws IOException {

	    this.peer = peer;
	    this.socket = socket;
	    this.clusterManager = clusterManager;

	    in = new BufferedReader(
	            new InputStreamReader(socket.getInputStream())
	    );
	}
	
	public void run() {
		String line;
		try {
			while ((line = in.readLine()) != null) {
				clusterManager.handleMessage(line, peer);
				
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
