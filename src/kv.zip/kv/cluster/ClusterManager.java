package kv.cluster;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.atomic.AtomicLong;

import kv.protocol.ExecutionStatus;
import kv.protocol.Response;

public class ClusterManager {

	private final String nodeId;
	private NodeRole role;

	private Map<String, PeerConnection> peers = new ConcurrentHashMap<>();;
	private String leaderId;

	private record ForwardedRequest(
			long requestId,
			PeerConnection originPeer
			) {}

	private Map<Long, CompletableFuture<Response>> pendingRequests =
			new ConcurrentHashMap<>();
	private Map<Long, ForwardedRequest> pendingForwardedRequests = new ConcurrentHashMap<>();
	private Set<Long> majorityAcked = ConcurrentHashMap.newKeySet();

	private AtomicLong nextRequestId = new AtomicLong(0);
	
	private long catchUpInProgressThrough = -1;

	private final OperationProcessor operationProcessor;
	private final ReplicationState repState;

	public ClusterManager(
			String nodeId,
			NodeRole role,
			OperationProcessor operationProcessor,
			ReplicationState repState) {

		this.nodeId = nodeId;
		this.role = role;
		this.operationProcessor = operationProcessor;
		this.repState = repState;
	}

	public void handleMessage(String msg, PeerConnection peer) throws IOException, InterruptedException {

		if (role == NodeRole.LEADER) {
			handleAsLeader(msg, peer);
		} else {
			handleAsFollower(msg, peer);
		}

	}

	public Response handleClientMutation(String[] tokens) throws InterruptedException, ExecutionException, IOException {
		long requestId = nextRequestId.getAndIncrement();

		CompletableFuture<Response> future = new CompletableFuture<>();

		pendingRequests.put(requestId, future);
		
		if (role != NodeRole.LEADER) {
			String message = "FORWARD " + requestId + " " + String.join(" ", tokens);
			sendToLeader(message);
			
		} else {
			operationProcessor.persistOperation(tokens);
			long logIndex = repState.getLogEnd();
			
			pendingForwardedRequests.put(
					logIndex,
					new ForwardedRequest(
							requestId,
							null
							)
					);
			
			String message = "REPLICATE " + logIndex + " " + String.join(" ", tokens);

			sendToFollowers(message);
			
		}

		

		return future.get();
	}

	public void sendToLeader(String message) {
		PeerConnection leader = peers.get(leaderId);
		leader.queueMessage(message);
	}

	public void sendToFollowers(String message) {
		if(role == NodeRole.FOLLOWER) {
			return;
		}

		for (PeerConnection follower : peers.values()) {
			follower.queueMessage(message);
		}
	}

	public void handleAsLeader(String msg, PeerConnection peer) throws IOException, InterruptedException {

		if (msg.startsWith("FORWARD ")) {
			String[] parts = msg.split(" ", 3);

			long requestId = Long.parseLong(parts[1]);
			String[] tokens = parts[2].split("\\s+");

			operationProcessor.persistOperation(tokens);

			long logIndex = repState.getLogEnd();

			pendingForwardedRequests.put(
					logIndex,
					new ForwardedRequest(
							requestId,
							peer
							)
					);

			String message = "REPLICATE " + logIndex + " " + String.join(" ", tokens);

			sendToFollowers(message);

		} else if (msg.startsWith("REPLICATE_ACK ")) {
			String[] parts = msg.split(" ");
			long ackedIndex = Long.parseLong(parts[1]);

			if (ackedIndex <= repState.getCommitIndex()) {
			    peer.queueMessage("COMMIT " + repState.getCommitIndex());
			    return;
			}
			
			majorityAcked.add(ackedIndex);

			long oldCommitIndex = repState.getCommitIndex();

			while (majorityAcked.contains(repState.getCommitIndex() +1)) {
				long nextIndex = repState.getCommitIndex() + 1;

				repState.advanceCommitIndex(nextIndex);

				majorityAcked.remove(nextIndex);
			}

			long newCommitIndex = repState.getCommitIndex();

			if (newCommitIndex > oldCommitIndex) {
				List<Response> responses = operationProcessor.applyCommittedThrough(); 


				int responseIndex = 0;

				for (long logIndex = oldCommitIndex + 1;
						logIndex <= newCommitIndex;
						logIndex++) {

					Response response = responses.get(responseIndex++);

					ForwardedRequest request =
							pendingForwardedRequests.remove(logIndex);

					if (request.originPeer() == null) {

					    CompletableFuture<Response> future =
					            pendingRequests.remove(request.requestId());

					    future.complete(response);

					} else {

						String payload = response.getPayload();

						String message =
						        "RESULT "
						        + request.requestId() + " "
						        + response.getStatus().name() + " "
						        + (payload == null ? "" : payload);

						request.originPeer().queueMessage(message);
					}
				}


				sendToFollowers("COMMIT " + newCommitIndex);
			}

		} else if (msg.startsWith("CATCHUP_REQUEST ")) {
			String[] parts = msg.split(" ");
			String reason = parts[1];
			Long followerLogEnd = Long.parseLong(parts[2]);
			Long target = Long.parseLong(parts[3]);
			
			List<String[]> catchUp = operationProcessor.loadCatchUpFromLog(followerLogEnd, target);
			
			for(String[] operation : catchUp) {
				peer.queueMessage("CATCHUP " + reason +" "+ target + " " + String.join(" ", operation));
			}
			
			peer.queueMessage("CATCHUP_DONE " + reason +" "+ target);

		} else {
			System.err.println(
			        "Unknown cluster message received by leader: " + msg
			    );

		}
	}

	public void handleAsFollower(String msg, PeerConnection peer) throws IOException, InterruptedException {
		if (msg.startsWith("REPLICATE ")) {
			Long logEnd = repState.getLogEnd();
			
			String[] parts = msg.split(" ", 3);
			Long logIndex = Long.parseLong(parts[1]); 
			String[] tokens = parts[2].split(" ");
			
			if (logEnd < logIndex - 1) {

			    if (logIndex > catchUpInProgressThrough) {
			        catchUpInProgressThrough = logIndex;

			        sendToLeader(
			            "CATCHUP_REQUEST REPLICATE "
			            + logEnd + " " + logIndex
			        );
			    }

			} else if (logEnd >= logIndex) {
			    sendToLeader("REPLICATE_ACK " + logIndex);
			    return;

			} else {
			    operationProcessor.persistOperation(tokens);
			    sendToLeader("REPLICATE_ACK " + logIndex);
			}

		} else if (msg.startsWith("COMMIT ")) {

		    long commitIndex = repState.getCommitIndex();
		    long logEnd = repState.getLogEnd();

		    long newCommitIndex =
		            Long.parseLong(msg.split(" ")[1]);

		    if (logEnd < newCommitIndex) {
		        if (newCommitIndex > catchUpInProgressThrough) {
		            catchUpInProgressThrough = newCommitIndex;

		            sendToLeader(
		                "CATCHUP_REQUEST COMMIT "
		                + logEnd + " " + newCommitIndex
		            );
		        }

		    } else if (newCommitIndex > commitIndex) {

		        repState.advanceCommitIndex(newCommitIndex);
		        operationProcessor.applyCommittedThrough();
		    }

		} else if (msg.startsWith("RESULT ")) {
			String[] parts = msg.split(" ", 4);
			
			Long requestId = Long.parseLong(parts[1]);
			
			ExecutionStatus status =
		            ExecutionStatus.valueOf(parts[2]);

		    String payload =
		            parts.length == 4 ? parts[3] : null;

		    Response response = new Response(status, payload);

		    CompletableFuture<Response> future =
		            pendingRequests.remove(requestId);

		    future.complete(response);

		} else if (msg.startsWith("CATCHUP ")) {

			// TODO: receive/apply missing log entries

		} else {
			System.err.println(
			        "Unknown cluster message received by leader: " + msg
			    );
		}
	}



}
